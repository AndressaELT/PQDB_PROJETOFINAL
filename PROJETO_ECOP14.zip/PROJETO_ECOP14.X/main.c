//Tanque de 255 Litros

//inclusao das bibliotecas
#include <pic18f4520.h>
#include "config.h"
#include "lcd.h"
#include "funcao.h"
#include "serial.h"
#include "adc.h"
#include "ssd.h"
#include "timer.h"
#include "keypad.h"
#include "bits.h"
#include "pwm.h"
#include "atraso.h"

//definindo comandos do lcd
#define L_ON 0x0F
#define L_OFF 0x08
#define L_CLR 0x01
#define L_L1 0x80
#define L_L2 0xC0

void main(void) {
    char controle = 0;
    char ajuste = 0;
    unsigned int tecla;
    unsigned int y;
    
    //inicializa��o de lcd,serial,potenciometro,timer,teclado e pwm
    lcdInit();
    serial_init();
    adcInit();
    ssdInit();
    timerInit();
    kpInit();
    pwmInit();

    for (;;) {
        timerReset(20000);
        switch(controle){
            case 0:
                ajuste = 0;
                QuantidadeLitros ();
                controle = 9;
            break;
            
            case 1:
                tempinicial();
                controle = 9;
            break;
            case 2:
                tempfinal();
                controle = 9;
            break;
            case 3:
                lcdCommand(0x80);
                lcdString("Potencia:");
                Potencia();
                controle = 9;
            break;
             
            case 4:
                atualizaSistema();
                controle = 9;
            break;
            
            case 5:
                tempo(&y);
                y+=6000;
                controle = 6;
            break;
            
            case 6:
                ssdDigit(((y/6000) %10), 3); 
                ssdDigit(((y/60000)%6), 2);  
                ssdDigit((((y/360000)%24)%10), 1); 
                ssdDigit((((y/360000)%24)/10), 0); 
                controle = 7;
            break;
            
            case 7:
                if(y == 6000){
                    y=0;
                    finaliza();
                    pwmSet(100);                      
                    atraso_ms(500);
                    pwmSet(0);
                    atraso_ms(500);
                    pwmSet(100);                      
                    atraso_ms(500);
                    pwmSet(0);
                    atraso_ms(500);
                    pwmSet(100);                      
                    atraso_ms(500);
                    pwmSet(0);
                    controle = 8;
                }
                else{
                    y=y-4;
                   controle = 6; 
                } 
            break;
            
            case 8:
                y=0;
                lcdCommand(0x01);
                lcdCommand(0x80);
                lcdString("Nova operacao?");
                controle = 9;
            break;
            
            case 9:
                kpDebounce();
                if (kpRead() != tecla) {
                    tecla = kpRead();
                    if (bitTst(tecla, 9)) {//SW102
                        pwmSet(100);
                        atraso_ms(50);
                        pwmSet(0);
                        ajuste++;
                        controle = ajuste;
                        if(ajuste == 6){
                            controle = 0;
                        }
                    }
                    else if (bitTst(tecla, 4)) {//SW101
                        pwmSet(100);
                        atraso_ms(50);
                        pwmSet(0);
                        if(ajuste != 0){
                        ajuste--;
                        controle = ajuste;
                        }
                    }
                }
                if(ajuste == 3){
                    controle = 3;
                }
            break;
            default:
            break;
        }
        ssdUpdate(); //atualiza os displays  
        timerWait();  //espera a contagem do timerReset acabar
    }
}