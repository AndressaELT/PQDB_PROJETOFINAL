//inclusao das bibliotecas
#include "funcao.h"
#include "lcd.h"
#include "serial.h"
#include "adc.h"
#include "atraso.h"



int i; //variavel para percorrer o vetor
unsigned char litros[3]; //vetor para armazenar os digitos do serial
unsigned char lit;
unsigned char inicial[3];
unsigned char tempi;
unsigned char final[3];
unsigned char tempf;
char vpot;
int pot;

void finaliza(void){
    vpot = 0;
    while(lit>0){
        lcdPosition(1,0);
        lcdString("L:");
        lcdChar((lit / 1000) % 10 + 48);
        lcdChar((lit / 100) % 10 + 48);
        lcdChar((lit / 10) % 10 + 48);
        lcdChar(lit % 10 + 48); 
        lcdString(" | ");
        lcdString("P:");
        lcdChar((vpot / 1000) % 10 + 48);
        lcdChar((vpot / 100) % 10 + 48);
        lcdChar((vpot / 10) % 10 + 48);
        lcdChar(vpot % 10 + 48);
        lcdString("%"); // imprime % no lcd
        lcdPosition(0,0);
        lcdChar((tempf / 1000) % 10 + 48);
        lcdChar((tempf / 100) % 10 + 48);
        lcdChar((tempf / 10) % 10 + 48);
        lcdChar(tempf % 10 + 48); 
        lcdChar(0xdf);
        lcdString("C");
        lcdString(" -> ");
        lcdChar((tempf / 1000) % 10 + 48);
        lcdChar((tempf / 100) % 10 + 48);
        lcdChar((tempf / 10) % 10 + 48);
        lcdChar(tempf % 10 + 48);
        lcdChar(0xDF);
        lcdString("C");
        lit--;
        atraso_ms(50);
    }
}
void tempo(unsigned int *y){
    *y = ((((tempi-tempf)/(vpot/100))*lit)*10);
}
void QuantidadeLitros (void){
    unsigned char l;
    i = 0;
    lcdCommand(0x01);
    lcdCommand(0x80);
    lcdString("Insira os Litros");
    serial_tx_str("Digite a quantidade de Litros:");
    while(i<2){
        l = serial_rx(6000);   
        if(l){
            litros[i] = l;
            serial_tx(l);
            i++;
        }
    }
    litros[i] = '\0';
    lit = 10*(litros[0]-48)+10*(litros[1]-48);
    serial_tx_str("\r\n FIM!\r\n");
    lcdPosition(1,0);
    lcdString("L:");
    lcdChar((lit / 1000) % 10 + 48);
    lcdChar((lit / 100) % 10 + 48);
    lcdChar((lit / 10) % 10 + 48);
    lcdChar(lit % 10 + 48);
    lcdString(" Confirma?");
}
void tempinicial (void){
    unsigned char ti;
    i = 0;
    lcdCommand(0x01);
    lcdCommand(0x80);
    lcdString("Temperatura:");
    serial_tx_str("Digite a temperatura inicial:");
    while(i<2){
        ti = serial_rx(6000);   
        if(ti){
            inicial[i] = ti;
            serial_tx(ti);
            i++;
        }
    }
    inicial[i] = '\0';
    tempi = 10*(inicial[0]-48)+(inicial[1]-48);
    serial_tx_str("\r\n FIM!\r\n");
    lcdCommand(0x01);
    lcdPosition(0,0);
    lcdString("T:");
    lcdChar((tempi / 1000) % 10 + 48);
    lcdChar((tempi / 100) % 10 + 48);
    lcdChar((tempi / 10) % 10 + 48);
    lcdChar(tempi % 10 + 48); 
    lcdChar(0xdf);
    lcdString("C");
    lcdPosition(1,6);
    lcdString(" Confirma?");
}
void tempfinal (void){
    unsigned char tf;
    i = 0;
    lcdCommand(0x01);
    lcdCommand(0x80);
    lcdString("Temperatura:");
    serial_tx_str("Digite a temperatura final:");
    while(i<2){
        tf = serial_rx(6000);   
        if(tf){
            final[i] = tf;
            serial_tx(tf);
            i++;
        }
    }
    final[i] = '\0';
    tempf = 10*(final[0]-48)+(final[1]-48);
    serial_tx_str("\r\n FIM!\r\n"); 
    lcdCommand(0x01);
    lcdPosition(0,0);
    lcdString("T:");
    lcdChar((tempf / 1000) % 10 + 48);
    lcdChar((tempf / 100) % 10 + 48);
    lcdChar((tempf / 10) % 10 + 48);
    lcdChar(tempf % 10 + 48); 
    lcdChar(0xdf);
    lcdString("C");
    lcdPosition(1,6);
    lcdString(" Confirma?");    
}

void Potencia(void){
        pot = adcRead(0);
        if(pot>768){
            vpot = 100;
        }
        if(pot>512 && pot<768){
            vpot = 75;;
        }
        if(pot>256 && pot<512){
            vpot = 50;
        }
        if(pot>0 && pot<256){
            vpot = 25;            
        }
        if(pot == 0){
            vpot = 0;
        }
        lcdPosition(1,0);
        lcdString("P:");
        lcdChar((vpot / 1000) % 10 + 48);
        lcdChar((vpot / 100) % 10 + 48);
        lcdChar((vpot / 10) % 10 + 48);
        lcdChar(vpot % 10 + 48);
        lcdPosition(1,6);
        lcdString(" Confirma?"); 
}

void atualizaSistema (void){
        lcdPosition(1,0);
        lcdString("L:");
        lcdChar((lit / 1000) % 10 + 48);
        lcdChar((lit / 100) % 10 + 48);
        lcdChar((lit / 10) % 10 + 48);
        lcdChar(lit % 10 + 48); 
        lcdString(" | ");
        lcdString("P:");
        lcdChar((vpot / 1000) % 10 + 48);
        lcdChar((vpot / 100) % 10 + 48);
        lcdChar((vpot / 10) % 10 + 48);
        lcdChar(vpot % 10 + 48);
        lcdString("%"); // imprime % no lcd
        lcdPosition(0,0);
        lcdChar((tempi / 1000) % 10 + 48);
        lcdChar((tempi / 100) % 10 + 48);
        lcdChar((tempi / 10) % 10 + 48);
        lcdChar(tempi % 10 + 48); 
        lcdChar(0xdf);
        lcdString("C");
        lcdString(" -> ");
        lcdChar((tempf / 1000) % 10 + 48);
        lcdChar((tempf / 100) % 10 + 48);
        lcdChar((tempf / 10) % 10 + 48);
        lcdChar(tempf % 10 + 48);
        lcdChar(0xDF);
        lcdString("C");
    return;
}

