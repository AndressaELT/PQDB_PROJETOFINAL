#ifndef FUNCAO_H
#define	FUNCAO_H

void QuantidadeLitros (void);
void tempinicial (void);
void tempfinal(void);
void Potencia (void);
void tempo(unsigned int *y);
void finaliza(void);
void atualizaSistema (void);

#endif	/* TEMP_H */
